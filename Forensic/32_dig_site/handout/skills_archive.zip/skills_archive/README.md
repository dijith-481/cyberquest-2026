# skills_archive

Import of the pre-merger skill matrix into the new HR system.

Every import timestamp came out in the 1980s. The vendor says the dates
were "preserved from the source system." The source system was a spreadsheet.
The spreadsheet was written in 2024. Nobody wants to talk about it.

The archive was exported in pieces and reassembled by hand, on a machine
that "has never lost anything, technically." Housekeeping has been on the
backlog since the import. Several candidate imports never made it to a
branch. Ask fsck.

- skills/ — one file per skill, exactly as imported
