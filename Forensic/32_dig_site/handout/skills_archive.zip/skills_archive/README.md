# skills_archive

Import of the pre-merger skill matrix into the new HR system.

Every import timestamp came out in the 1980s. The vendor says the dates
were "preserved from the source system." The source system was a spreadsheet.
The spreadsheet was written in 2024. Nobody wants to talk about it.

Import ran from `archive-import`. The main branch was fast-forwarded after
legal reviewed "the wording." Several candidate imports never made it to a
branch. Housekeeping has been on the backlog since the import.

- skills/ — one file per skill, exactly as imported
