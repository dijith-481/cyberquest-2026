# Alibi Weaving

STATUS: lost
Practitioners could produce three mutually consistent
accounts of the same afternoon. Deprecated after legal reviewed
the concept of 'three'.
