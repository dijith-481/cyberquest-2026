# Arrow Sorting

STATUS: lost
Sorted arrows by intent rather than by direction.
Warehouse staff loved it. OSHA did not return our calls.
