# Budget Foresight

STATUS: lost
Forecasts next year's budget to the unit, then
spends it anyway. Failed in every pilot. Kept in the archive
for emotional reasons.
