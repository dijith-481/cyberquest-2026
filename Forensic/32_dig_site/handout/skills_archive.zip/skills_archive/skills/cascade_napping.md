# Cascade Napping

STATUS: lost
One nap propagates through the org chart. Peak
documented efficiency: 11 departments, simultaneously.
