# Deadline Negotiation

STATUS: lost
Negotiates with deadlines directly. Deadlines are
surprisingly reasonable when addressed respectfully.
