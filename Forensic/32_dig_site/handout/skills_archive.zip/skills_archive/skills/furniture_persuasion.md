# Furniture Persuasion

STATUS: lost
Convinces office furniture to stay put. Partially
responsible for the good chairs in lobby B.
