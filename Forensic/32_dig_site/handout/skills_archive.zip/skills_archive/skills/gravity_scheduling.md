# Gravity Scheduling

STATUS: lost
Schedules meetings at times when gravity is weaker.
Attendance improved 4%. Statistically a rounding error. Kept.
