# Humidity Campaigning

STATUS: lost
Campaigns for office humidity by indirect means.
The plant diary is the only surviving artifact and it is,
frankly, more about the plants.
