# Implication Mowing

STATUS: lost
The lawn is mowed the moment someone implies it
should be. Nobody knows who mows it. Do not investigate.
