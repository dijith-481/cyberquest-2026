# Journal Deflection

STATUS: lost
Redirects awkward questions into a journal that
is then lost. The journal is never lost. That is the skill.
