# Keystroke Empathy

STATUS: lost
Feels which keys are pressed with intent and
which are pressed with despair. QA refuses to be certified in it.
