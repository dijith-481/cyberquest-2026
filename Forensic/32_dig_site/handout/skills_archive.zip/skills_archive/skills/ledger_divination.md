# Ledger Divination

STATUS: lost
Reads next quarter's expenses in the smudge
patterns of the current ledger. Accuracy: 61%. Which is still
better than the deck.
