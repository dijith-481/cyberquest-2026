# Meeting Apport

STATUS: lost
Teleports a meeting to whoever is least prepared.
Imported twice by mistake. Both copies work. Do not run both.
