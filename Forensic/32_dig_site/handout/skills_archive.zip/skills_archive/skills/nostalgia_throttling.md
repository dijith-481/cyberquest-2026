# Nostalgia Throttling

STATUS: lost
Caps how often anyone can say 'in the old universe
we did it like this' to twice per standup. Enforcement lapsed.
