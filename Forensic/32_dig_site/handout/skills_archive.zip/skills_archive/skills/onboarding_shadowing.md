# Onboarding Shadowing

STATUS: lost
The shadow shows up first and does the work.
The new hire arrives to find everything done and one extra
coffee mug. HR policy is silent on extra mugs.
