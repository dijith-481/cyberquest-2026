# Parking Orthodoxy

STATUS: lost
Assigns parking by a formula nobody can parse.
The formula was lost. The assignments continue anyway.
