# Quiet Hours Ritual

STATUS: lost
Two hours of enforced silence per week, observed
by everyone including the printer. The printer observance is
regarded as the most credible part.
