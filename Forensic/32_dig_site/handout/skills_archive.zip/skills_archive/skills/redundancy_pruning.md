# Redundancy Pruning

STATUS: lost
Identifies work that duplicates other work and
prunes it. Attempted on this very archive. Failed, obviously.
