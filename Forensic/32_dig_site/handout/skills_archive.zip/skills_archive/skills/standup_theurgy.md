# Standup Theurgy

STATUS: lost
Summons a standup that already happened and asks
it what it meant. Findings: 'blocked, spiritually.'
