# Toner Communion

STATUS: lost
Negotiates with printers as equals. The only skill
on this list with documented success. Kevin teaches it informally.
