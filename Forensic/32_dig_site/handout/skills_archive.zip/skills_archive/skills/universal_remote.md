# Universal Remote

STATUS: lost
One remote for every device in the building,
including the building. Tested once. The building declined.
