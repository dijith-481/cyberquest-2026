# Vendetta Accounting

STATUS: lost
Tracks grudges as liabilities with amortization.
Finance declined to adopt it and adopted it privately.
