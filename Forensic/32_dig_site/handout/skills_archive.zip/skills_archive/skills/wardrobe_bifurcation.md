# Wardrobe Bifurcation

STATUS: lost
Splits a wardrobe across two universes so laundry
is always done somewhere. Legal has questions. The questions
are about the shirts, not the universes.
